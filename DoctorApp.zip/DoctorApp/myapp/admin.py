from django.contrib import admin
from .models import Userdata,Userdata2,PatientDetails,Alogin

admin.site.register(Userdata)
admin.site.register(Userdata2)
admin.site.register(PatientDetails)
admin.site.register(Alogin)
# Register your models here.
